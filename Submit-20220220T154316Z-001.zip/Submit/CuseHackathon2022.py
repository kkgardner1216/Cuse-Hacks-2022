import csv
import requests
import json
print("Starting street number: ")
st_num = str(input())
print("Starting street (exlude classification): ")
st_rd = str(raw_input())
print("Starting road classification (Avenue, ST, Drive, RD etc.): ")
st_cl = str(raw_input())
print("End street number: ")
end_num = str(input())
print("End street (exlude classification): ")
end_rd = str(raw_input())
print("End road classification (Avenue, ST, Drive, RD etc.): ")
end_cl = str(raw_input())
#url = "https://maps.googleapis.com/maps/api/directions/json?origin=728+Ackerman+Avenue+Syracuse+NY&destination=831+Westcott+ST+Syracuse+NY&key=AIzaSyCQyJPhPj62D28Q9cmkitNt6W3tt6yYnp4"
url = "https://maps.googleapis.com/maps/api/directions/json?origin=" + st_num + "+" + st_rd + "+" + st_cl + "+Syracuse+NY&destination=" + end_num + "+" + end_rd + "+" + end_cl + "Syracuse+NY&key=AIzaSyCQyJPhPj62D28Q9cmkitNt6W3tt6yYnp4"
payload={}
headers={}
response = requests.request("GET", url, headers=headers, data=payload)
data = response.json()
#print(response.text)
json_string = json.dumps(data)
with open("json_data.json", "w") as outfile:
	json.dump(json_string,outfile)

length = len((data['routes'][0]['legs'][0]['steps']))
#print(length)
i = 0
x = 0
y = 0
z = 0
roads = []
while (i < length):
	text = str(data['routes'][0]['legs'][0]['steps'][i]['html_instructions'])
	x = text.find("<b>",0)
	y = text.find("<b>",x+1)
	z = text.find("</b>",y+1)
	roads.append(text[y+3:z])
	i+=1
i = 0

while (i< len(roads)):
	roads[i] = roads[i].lower()
	print(roads[i])
	i+=1

with open('new_new_ratings.csv') as file:
    rating = []
    street = []
    line = file.readline()
    line = file.readline()
    while line != "":
#		lookup = {line.split(',')[1] : line.split(',')[2]}
		rating.append(line.split(',')[2])
		street.append(line.split(',')[1])
		line = file.readline()
#    print("Rating: ", rating)
#    print("Street Name: ", streetName)

file.close()
lookup = {}
while (i<len(rating)):
	lookup.update({street[i] : rating[i]})
	i +=1
#print(lookup['"alliance bank pkwy"'])
i = 0 
j = 0
total = 0.0
while (i < len(roads)):
	try:
		total = total + float(lookup['"' + roads[i] + '"'])
		i+=1
		j+=1
	except:
		print(roads[i])
		print("street not found")
		i+=1
#print('"' + roads[1] +'"')
#print(lookup['"' + roads[1] + '"'])
avg = total/j
print("Average road quality: " + str(avg))

#str(data['routes'][0]['legs'][0]['steps'][0]['html_instructions'].split())
#type(data['routes'][0]['legs'][0]['steps'][0]['html_instructions']).encode('ascii','ignore')
#json_text = str(response.text)
#json_split = json_text(" ")
#json_string = json.dumps(data)
#jsondict = json.loads(json_string)
#print(jsondict.get(u'routes'))
#f = open('json_data',)
#data = json.load(f)

#print(response.text)
#response = requests.get("https://maps.googleapis.com/maps/api/directions/json?origin=Disneyland&destination=Universal+Studios+Hollywood&key=AIzaSyCQyJPhPj62D28Q9cmkitNt6W3tt6yYnp4")
#response.status_code
#data2 = response.json()
#json_string = json.dumps(data2)

#print(json_string)
#with open('json_data.json','w') as outfile:
#	outfile.write(json_string)
#print("hello world")

#import requests
#import json

#url = "https://maps.googleapis.com/maps/api/directions/json?origin=728+Ackerman+Avenue+Syracuse+NY&destination=175+Small+Road+Syracuse+NY&key=AIzaSyCQyJPhPj62D28Q9cmkitNt6W3tt6yYnp4"
#payload={}
#headers={}
#response = requests.request("GET", url, headers=headers, data=payload)
#data = response.json()
#print(response.text)
#json_string = json.dumps(data)
#with open("json_data.json", "w") as outfile:
#	json.dump(json_string,outfile)
#string_json = data(['routes'][0]['legs'][0]['steps'][0]['html_instructions']).encode('ascii','ignore')
#print(string_json)
#print(type(data(['routes'][0]['legs'][0]['steps'][0]['html_instructions'][0])))